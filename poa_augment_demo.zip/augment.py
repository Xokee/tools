#!/usr/bin/env python3
"""Simulate real-world capture quality on rendered synthetic documents (for OCR / document-AI robustness).

  python augment.py results/English/Singapore/Singapore_electric.pdf --mode photo --level all --out aug_out
  python augment.py some_dir/ --mode scan --level medium --out aug_out      # whole directory of PDFs

Modes
  photo : paper lying on a desk, perspective + rotation, cast shadow, uneven light, vignette, defocus/motion blur, noise, JPEG
  scan  : flat scan / screenshot-like, slight skew, yellowing, grain, low resolution, JPEG
Levels: light | medium | heavy | all

The SPECIMEN watermark of the source document is kept (effects are applied on top of the rendered page).
Pipeline order matters: lighting/shadow on the paper -> geometry -> blur -> sensor noise -> resolution loss -> JPEG.
"""
import argparse, subprocess, tempfile
from pathlib import Path
import cv2
import numpy as np

LEVELS = {
    #            rot°  persp  blur  motion  shadow light  noise  down   jpeg
    "light":  dict(rot=1.0, persp=0.010, blur=0.6, motion=0, shadow=0.15, light=0.10, noise=3,  down=0.90, jpeg=85),
    "medium": dict(rot=3.0, persp=0.030, blur=1.2, motion=5, shadow=0.35, light=0.20, noise=6,  down=0.75, jpeg=65),
    "heavy":  dict(rot=6.0, persp=0.060, blur=2.0, motion=11, shadow=0.55, light=0.35, noise=11, down=0.55, jpeg=38),
}


def render_pdf(pdf, dpi=150):
    with tempfile.TemporaryDirectory() as d:
        subprocess.run(["pdftoppm", "-r", str(dpi), "-png", "-f", "1", "-l", "1", str(pdf), f"{d}/p"], check=True)
        img = cv2.imread(next(Path(d).glob("p*.png")).as_posix())
    return img.astype(np.float32) / 255.0


def paper_tone(img, rng, k):
    tint = np.array([0.90, 0.95, 0.98], np.float32) if rng.random() < 0.7 else np.array([0.97, 0.97, 0.97], np.float32)
    img = img * (1 - k + k * tint)  # slight yellowing / grey paper
    grain = rng.normal(0, 0.012 + 0.02 * k, img.shape[:2]).astype(np.float32)
    return img + grain[..., None]


def soft_shadow(img, rng, strength):
    """Large soft-edged dark region, like a hand / phone / window frame casting a shadow."""
    h, w = img.shape[:2]
    m = np.zeros((h, w), np.float32)
    kind = rng.choice(["band", "corner", "blob"])
    if kind == "band":      # diagonal band
        x0, x1 = rng.uniform(0.0, 0.5) * w, rng.uniform(0.5, 1.0) * w
        pts = np.array([[x0, 0], [x0 + rng.uniform(0.15, 0.35) * w, 0], [x1, h], [x1 - rng.uniform(0.15, 0.35) * w, h]], np.int32)
        cv2.fillPoly(m, [pts], 1.0)
    elif kind == "corner":
        c = rng.choice([0, 1]) * w
        cv2.circle(m, (int(c), int(rng.choice([0, 1]) * h)), int(rng.uniform(0.35, 0.6) * max(h, w)), 1.0, -1)
    else:
        cv2.ellipse(m, (int(rng.uniform(0.2, 0.8) * w), int(rng.uniform(0.2, 0.8) * h)),
                    (int(rng.uniform(0.15, 0.35) * w), int(rng.uniform(0.1, 0.3) * h)), rng.uniform(0, 180), 0, 360, 1.0, -1)
    sigma = 0.06 * max(h, w)
    m = cv2.GaussianBlur(m, (0, 0), sigma)
    return img * (1 - strength * m[..., None])


def uneven_light(img, rng, k):
    h, w = img.shape[:2]
    ang = rng.uniform(0, 2 * np.pi)
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    g = (xx / w - 0.5) * np.cos(ang) + (yy / h - 0.5) * np.sin(ang)
    img = img * (1 + k * g[..., None] * 1.6)
    r = np.sqrt(((xx / w) - 0.5) ** 2 + ((yy / h) - 0.5) ** 2)  # vignette
    return img * (1 - 0.9 * k * (r ** 2)[..., None])


def make_desk(h, w, rng):
    base = np.array(rng.choice([[0.25, 0.32, 0.42], [0.55, 0.60, 0.62], [0.18, 0.18, 0.20], [0.40, 0.48, 0.60]]), np.float32)
    low = cv2.GaussianBlur(rng.normal(0, 1, (h, w)).astype(np.float32), (0, 0), 25)
    low = low / (np.abs(low).max() + 1e-6) * 0.10
    fine = rng.normal(0, 0.02, (h, w)).astype(np.float32)
    return np.clip(base[None, None, :] + (low + fine)[..., None], 0, 1)


def place_on_desk(img, rng, p):
    H, W = img.shape[:2]
    pad = int(0.10 * max(H, W)); ch, cw = H + 2 * pad, W + 2 * pad
    src = np.float32([[0, 0], [W, 0], [W, H], [0, H]])
    ang = np.deg2rad(rng.uniform(-p["rot"], p["rot"]))
    R = np.array([[np.cos(ang), -np.sin(ang)], [np.sin(ang), np.cos(ang)]], np.float32)
    ctr = np.float32([cw / 2, ch / 2])
    dst = (src - np.float32([W / 2, H / 2])) @ R.T + ctr
    dst += rng.uniform(-p["persp"], p["persp"], dst.shape).astype(np.float32) * np.float32([W, H])
    M = cv2.getPerspectiveTransform(src, dst.astype(np.float32))
    warped = cv2.warpPerspective(img, M, (cw, ch), flags=cv2.INTER_CUBIC, borderValue=(0, 0, 0))
    mask = cv2.warpPerspective(np.ones((H, W), np.float32), M, (cw, ch), flags=cv2.INTER_LINEAR)
    mask = cv2.GaussianBlur(mask, (0, 0), 0.8)
    desk = make_desk(ch, cw, rng)
    sh = cv2.GaussianBlur(np.roll(mask, (int(0.012 * ch), int(0.008 * cw)), axis=(0, 1)), (0, 0), 0.01 * max(ch, cw))
    desk = desk * (1 - 0.5 * sh[..., None])  # contact shadow under the sheet
    return warped * mask[..., None] + desk * (1 - mask[..., None])


def place_scan(img, rng, p):
    H, W = img.shape[:2]
    ang = rng.uniform(-p["rot"], p["rot"]) * 0.5
    M = cv2.getRotationMatrix2D((W / 2, H / 2), ang, 1.0)
    return cv2.warpAffine(img, M, (W, H), flags=cv2.INTER_CUBIC, borderValue=(0.98, 0.98, 0.98))


def motion_blur(img, length, rng):
    if length < 2:
        return img
    k = np.zeros((length, length), np.float32); k[length // 2, :] = 1
    M = cv2.getRotationMatrix2D((length / 2 - 0.5, length / 2 - 0.5), rng.uniform(0, 180), 1)
    k = cv2.warpAffine(k, M, (length, length)); k /= k.sum() + 1e-6
    return cv2.filter2D(img, -1, k)


def degrade(img, mode, level, seed):
    rng = np.random.default_rng(seed)
    p = LEVELS[level]
    k = {"light": 0.3, "medium": 0.6, "heavy": 0.9}[level]
    img = paper_tone(img, rng, k * 0.6)
    img = soft_shadow(img, rng, p["shadow"]) if (mode == "photo" or rng.random() < 0.4) else img
    img = uneven_light(img, rng, p["light"] if mode == "photo" else p["light"] * 0.4)
    img = np.clip(img, 0, 1)
    img = place_on_desk(img, rng, p) if mode == "photo" else place_scan(img, rng, p)
    if p["blur"] > 0:
        img = cv2.GaussianBlur(img, (0, 0), p["blur"] * (1.0 if mode == "photo" else 0.6))   # defocus
    img = motion_blur(img, p["motion"] if mode == "photo" else 0, rng)                      # hand shake
    img = img + rng.normal(0, p["noise"] / 255.0, img.shape).astype(np.float32)           # sensor noise
    h, w = img.shape[:2]
    d = p["down"]
    img = cv2.resize(cv2.resize(img, (int(w * d), int(h * d)), interpolation=cv2.INTER_AREA), (w, h), interpolation=cv2.INTER_LINEAR)
    img8 = (np.clip(img, 0, 1) * 255).astype(np.uint8)
    ok, buf = cv2.imencode(".jpg", img8, [cv2.IMWRITE_JPEG_QUALITY, p["jpeg"]])
    return cv2.imdecode(buf, cv2.IMREAD_COLOR), buf.tobytes()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src", help="PDF file or directory of PDFs")
    ap.add_argument("--mode", choices=["photo", "scan"], default="photo")
    ap.add_argument("--level", choices=[*LEVELS, "all"], default="all")
    ap.add_argument("--out", default="aug_out"); ap.add_argument("--seed", type=int, default=1); ap.add_argument("--dpi", type=int, default=150)
    a = ap.parse_args()
    src = Path(a.src); pdfs = sorted(src.rglob("*.pdf")) if src.is_dir() else [src]
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    for pdf in pdfs:
        base = render_pdf(pdf, a.dpi)
        for level in (LEVELS if a.level == "all" else [a.level]):
            _, jpg = degrade(base, a.mode, level, a.seed)
            (out / f"{pdf.stem}__{a.mode}_{level}.jpg").write_bytes(jpg)
            print("wrote", f"{pdf.stem}__{a.mode}_{level}.jpg")


if __name__ == "__main__":
    main()
