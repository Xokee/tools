#!/usr/bin/env python3
"""Fill every template with the ground-truth PROFILES and render PDFs + manifest.json.
  python generate_from_profiles.py --out results [--watermark-text "SPECIMEN"] [--seed 7]
Name / address / city / postcode / country / landlord come from profiles.py; account numbers,
dates, amounts and other filler are generated (seeded, reproducible)."""
import argparse, json, random
from pathlib import Path
from jinja2 import Environment, FileSystemLoader
import data_pools as dp
from i18n import labels
from generate import DOCS, BRAND_KIND, LABEL_KEY, build_ctx, TPL_DIR
from profiles import PROFILES, JOBS

def pdf_ok(path):
    try:
        with open(path, "rb") as fh:
            fh.seek(-32, 2); return b"%%EOF" in fh.read()
    except OSError:
        return False

def slug(s): return s.replace(" ", "_")

def addr_for(p, mode):
    if mode == "en":
        a = dict(p["en_parts"]); a["one_line"] = p["translated_address"]
    else:
        zp = p.get("zh_parts", {})
        a = dict(line1=p["address_line_1"], line2=p["address_line_2"], city=zp.get("city", p["city"]), state="",
                 postcode=p["postcode"] or "", country=zp.get("country", p["country"]), one_line=p["address"])
    return a

def apply_profile(c, doc, p, mode):
    a = addr_for(p, mode)
    name = p["translated_name"] if mode == "en" else p["name"]
    ll = p["translated_landlord_names"] if mode == "en" else p["landlord_names"]
    ll_addr = p["landlord_addr_en"] if mode == "en" else p.get("landlord_addr_zh", p["landlord_addr_en"])
    c["name"], c["addr"] = name, a
    if doc == "mgmt": c["unit"] = a["line2"] or a["line1"]
    if doc == "tenancy":
        c["prop_addr"] = a["one_line"]
        c["landlord"] = dict(name=ll, id=c["landlord"]["id"], addr=ll_addr)
    return dict(name=name, address=a["one_line"], address_line_1=a["line1"], address_line_2=a["line2"], city=a["city"] or p["city"],
                postcode=a["postcode"], country=a["country"], landlord=ll if doc == "tenancy" else None)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results"); ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--watermark-text", default=None); ap.add_argument("--html", action="store_true"); ap.add_argument("--group", default=None, help="only render this output group (English, Traditional_HK, Traditional_TW)")
    a = ap.parse_args()
    from weasyprint import HTML
    env = Environment(loader=FileSystemLoader(TPL_DIR), autoescape=True)
    css = (TPL_DIR / "_base.css").read_text()
    out = Path(a.out); manifest = []
    for group, key, region, mode in JOBS:
        if a.group and group != a.group: continue
        cfg = dp.REGIONS[region]; p = PROFILES[key]
        d = out / group / slug(key); d.mkdir(parents=True, exist_ok=True)
        for doc in DOCS:
            r = random.Random(f"{a.seed}-{key}-{group}-{doc}")
            t = labels(LABEL_KEY.get(doc, doc), cfg["lang"])
            c = build_ctx(doc, region, r, t)
            gt = apply_profile(c, doc, p, mode)
            b = dp.brand(BRAND_KIND[doc], region, r)
            html = env.get_template(f"{doc}.html.j2").render(t=t, c=c, b=b, css=css, html_lang=cfg["html_lang"], watermark_text=a.watermark_text)
            f = d / f"{slug(key)}_{doc}"
            if a.html: f.with_suffix(".html").write_text(html, encoding="utf-8")
            if not pdf_ok(f.with_suffix(".pdf")): HTML(string=html).write_pdf(f.with_suffix(".pdf"))  # resumable
            manifest.append(dict(file=str(f.with_suffix(".pdf").relative_to(out)), group=group, profile=key, template=doc,
                                 language=cfg["lang"], brand=b["name"], ground_truth=gt))
        print("done", group, key)
    (out / (f"manifest.{a.group}.json" if a.group else "manifest.json")).write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(len(manifest), "PDFs")

if __name__ == "__main__":
    main()
