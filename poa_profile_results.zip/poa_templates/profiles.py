"""Ground-truth profiles transcribed from the user's screenshot (PROFILES dict).
Fields marked EXTRA are not in the original dict: they are split/derived so the templates can fill
line1/line2/city/state/postcode separately in English, and landlord addresses are invented placeholders."""

PROFILES = {
    "Singapore": {
        "name": "Stefanie Sun", "translated_name": "Stefanie Sun",
        "address": "18 Example Lane, #05-12, Singapore 018989", "translated_address": "18 Example Lane, #05-12, Singapore 018989",
        "country": "Singapore", "city": "Singapore", "postcode": "018989",
        "address_line_1": "18 Example Lane", "address_line_2": "#05-12",
        "landlord_names": "JJ Lin", "translated_landlord_names": "JJ Lin",
        # EXTRA
        "en_parts": dict(line1="18 Example Lane", line2="#05-12", city="Singapore", state="", postcode="018989", country="Singapore"),
        "landlord_addr_en": "52 Sample Road, #12-03, Singapore 238888",
    },
    "Mainland China": {
        "name": "刘雯", "translated_name": "Liu Wen",
        "address": "中国广东省广州市天河区示例路88号2栋601室，510000",
        "translated_address": "Room 601, Building 2, 88 Example Road, Tianhe District, Guangzhou, Guangdong 510000, China",
        "country": "China", "city": "Guangzhou", "postcode": "510000",
        "address_line_1": "广东省广州市天河区示例路88号", "address_line_2": "2栋601室",
        "landlord_names": "刘亦菲", "translated_landlord_names": "Liu Yifei",
        # EXTRA
        "en_parts": dict(line1="Room 601, Building 2", line2="88 Example Road, Tianhe District", city="Guangzhou", state="Guangdong", postcode="510000", country="China"),
        "landlord_addr_en": "Room 1203, Building 5, 66 Sample Road, Tianhe District, Guangzhou, Guangdong 510000, China",
    },
    "Hong Kong": {
        "name": "劉德華", "translated_name": "Andy Lau",
        "address": "香港九龍示例道28號示例大廈12樓A室",
        "translated_address": "Flat A, 12/F, Example Building, 28 Example Road, Kowloon, Hong Kong",
        "country": "Hong Kong", "city": "Kowloon", "postcode": None,
        "address_line_1": "九龍示例道28號示例大廈", "address_line_2": "12樓A室",
        "landlord_names": "陳奕迅", "translated_landlord_names": "Eason Chan",
        # EXTRA
        "en_parts": dict(line1="Flat A, 12/F, Example Building", line2="28 Example Road", city="Kowloon", state="", postcode="", country="Hong Kong"),
        "zh_parts": dict(city="", country="香港"),
        "landlord_addr_en": "Flat B, 20/F, Sample Court, 15 Sample Street, Hong Kong Island, Hong Kong",
        "landlord_addr_zh": "香港港島樣本街15號樣本閣20樓B室",
    },
    "Taiwan": {
        "name": "周杰倫", "translated_name": "Jay Chou",
        "address": "台灣臺北市信義區示例路66號8樓之2，110",
        "translated_address": "8F-2, No. 66, Example Road, Xinyi District, Taipei 110, Taiwan",
        "country": "Taiwan", "city": "Taipei", "postcode": "110",
        "address_line_1": "臺北市信義區示例路66號", "address_line_2": "8樓之2",
        "landlord_names": "蔡依林", "translated_landlord_names": "Jolin Tsai",
        # EXTRA
        "en_parts": dict(line1="8F-2, No. 66, Example Road", line2="Xinyi District", city="Taipei", state="", postcode="110", country="Taiwan"),
        "zh_parts": dict(city="", country="台灣"),
        "landlord_addr_en": "5F, No. 120, Sample Road, Da'an District, Taipei 106, Taiwan",
        "landlord_addr_zh": "台灣臺北市大安區樣本路120號5樓，106",
    },
}

# (output group, profile key, template region, language mode)
JOBS = [
    ("English",        "Singapore",      "SG",    "en"),
    ("English",        "Mainland China", "CN_EN", "en"),
    ("English",        "Hong Kong",      "HK_EN", "en"),
    ("English",        "Taiwan",         "TW_EN", "en"),
    ("Traditional_HK", "Hong Kong",      "HK_ZH", "zh"),
    ("Traditional_TW", "Taiwan",         "TW",    "zh"),
]
