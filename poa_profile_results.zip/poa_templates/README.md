# Synthetic Proof-of-Address Template Pack

12 个 Jinja2/HTML 模板 × 5 个地区变体（SG、MY、HK_EN、HK_ZH、TW）= 60 种输出，英文 / 香港繁体 / 台湾繁体。
`sample_output/` 里有每种各 1 份已渲染的 PDF 和 HTML 样张。

## 内容

| 模板 | 类型 | 说明 |
|---|---|---|
| electric | 电费单 | 顶栏 + 摘要 + 读数 + 费用明细 |
| water_gas | 水费/煤气费 | 左侧色块栏的双栏版式 |
| telecom | 手机/宽带账单 | 摘要卡片 + 明细 |
| tv | 收费电视账单 | 横幅页眉 |
| mgmt | 管理费通知 | 居中页眉 + 信息表 |
| tenancy | 租赁协议 | 衬线字体、条款、三方签署栏 |
| gov | 政府部门函件 | 虚构部门 |
| tax | 评税通知书 | 虚构税务机构 |
| bank | 银行月结单（版式 A） | 交易明细表 |
| bank_card | 信用卡月结单（版式 B） | 摘要卡片 |
| fi_letter | 保险公司保单确认函 | 虚构保险公司 |
| employer | 在职证明 | 含公司印章占位 |

## 使用

    pip install -r requirements.txt
    python generate.py --region all --doc all --n 100 --out out --html
    python generate.py --region TW,HK_ZH --doc electric,bank --n 20 --out out

占位字段：姓名、地址（line1/line2/city/state/postcode/country）、房东姓名与地址、账号、日期、金额、
品牌名/电话/邮箱，全部由 `data_pools.py` 随机生成。换成你自己的姓名/地址来源，修改 `build_ctx()` 即可。

## 约定

- 所有机构名、logo 均为虚构，logo 为 `_macros.html.j2` 里自绘的 SVG，没有使用真实商标。
  虚构名称可能与现实机构偶然重名，投入使用前请自行核对。
- 每页带 SPECIMEN 水印（可用 `--watermark-text` 改文字），HTML 里带 synthetic 元数据。
- 证件类（NRIC、MyKad、护照、驾照）没有提供模板，建议使用 MIDV-2020 等公开合成数据集。
- 新增模板：在 `templates/` 加 `xxx.html.j2`（继承 `_layout.html.j2`），在 `i18n.py` 加三语文案，
  在 `generate.py` 的 `DOCS`、`BRAND_KIND` 和 `build_ctx()` 注册。

## 按 ground truth 填充（profiles.py）

    python generate_from_profiles.py --out results --html            # 全部 72 份
    python generate_from_profiles.py --out results --group Traditional_TW   # 只跑一组（中文渲染较慢，可分组、可续跑）

`profiles.py` 里是转录自截图的 PROFILES，加上标注为 EXTRA 的辅助字段（英文地址拆分、房东地址）。
英文组使用 translated_* 字段，繁体组使用中文字段；`manifest.json` 记录每份 PDF 对应的 ground truth 字段，可直接作标注。
