"""Synthetic data pools. All brands, people and addresses are fictional."""
import random
from datetime import date, timedelta

# region key -> settings. lang selects i18n labels, tpl_locale is the folder-free locale code
REGIONS = {
    "SG": dict(lang="en", country="Singapore", cur="S$", cur_code="SGD", html_lang="en",
               tel="+65 6{d3} {d4}", postcode="{d6}", city="Singapore", state=""),
    "MY": dict(lang="en", country="Malaysia", cur="RM", cur_code="MYR", html_lang="en",
               tel="+60 3-{d4} {d4}", postcode="{d5}", city=None, state=None),
    "HK_EN": dict(lang="en", country="Hong Kong SAR", cur="HK$", cur_code="HKD", html_lang="en",
                  tel="+852 2{d3} {d4}", postcode="", city=None, state=None),
    "HK_ZH": dict(lang="zh-HK", country="香港", cur="HK$", cur_code="HKD", html_lang="zh-HK",
                  tel="+852 2{d3} {d4}", postcode="", city=None, state=None),
    "TW": dict(lang="zh-TW", country="台灣", cur="NT$", cur_code="TWD", html_lang="zh-TW",
               tel="+886 2-{d4}-{d4}", postcode="{d3}", city=None, state=None),
}

NAMES = {
    "SG": ["Tan Wei Ming", "Lim Hui Ling", "Ng Kah Seng", "Chua Mei Xin", "Rajan Pillai", "Siti Nurhaliza Binte Ahmad",
           "Goh Jun Hao", "Teo Shu Fen", "Muhammad Irfan Bin Yusof", "Lee Zhi Wei", "Koh Pei Shan", "Ong Bing Hui"],
    "MY": ["Ahmad Faiz Bin Abdullah", "Nur Aisyah Binti Ismail", "Lee Chong Wei Jr", "Wong Siew Mei", "Kumar A/L Subramaniam",
           "Lim Soo Hui", "Tan Boon Keat", "Farah Nabilah Binti Hassan", "Chong Yee Ling", "Mohd Hafiz Bin Zainal"],
    "HK_EN": ["CHAN Tai Man", "WONG Siu Ming", "LEUNG Mei Ling", "LAM Ka Wai", "CHEUNG Wing Yee", "HO Chi Kin",
              "NG Pui Shan", "YEUNG Kwok Leung", "TSANG Hoi Ting", "LI Ka Yan"],
    "HK_ZH": ["陳大文", "黃小明", "梁美玲", "林家偉", "張詠儀", "何志堅", "吳佩珊", "楊國樑", "曾凱婷", "李嘉欣"],
    "TW": ["陳志明", "林雅婷", "黃建宏", "張淑芬", "李俊傑", "王怡君", "吳宗翰", "劉佩珊", "蔡明哲", "鄭惠雯"],
}

# (street/building line builder inputs)
MY_AREAS = [("Petaling Jaya", "Selangor", "47{d3}"), ("Kuala Lumpur", "Wilayah Persekutuan", "50{d3}"),
            ("Johor Bahru", "Johor", "80{d3}"), ("George Town", "Pulau Pinang", "10{d3}"), ("Shah Alam", "Selangor", "40{d3}")]
HK_DIST_EN = ["Kwun Tong, Kowloon", "Sha Tin, New Territories", "Tsuen Wan, New Territories", "Wan Chai, Hong Kong Island",
              "Mong Kok, Kowloon", "Quarry Bay, Hong Kong Island", "Tuen Mun, New Territories"]
HK_DIST_ZH = ["九龍觀塘", "新界沙田", "新界荃灣", "香港灣仔", "九龍旺角", "香港鰂魚涌", "新界屯門"]
TW_DIST = [("台北市", "大安區"), ("新北市", "板橋區"), ("台中市", "西屯區"), ("高雄市", "前鎮區"), ("桃園市", "中壢區"), ("台南市", "東區")]
TW_ROADS = ["中山路", "復興路", "民生路", "和平東路", "中正路", "文心路"]

def _d(n, r): return "".join(str(r.randint(0, 9)) for _ in range(n))

def fmt(tpl, r):
    return tpl.format(d3=_d(3, r), d4=_d(4, r), d5=_d(5, r), d6=_d(6, r))

def make_address(region, r):
    """Return dict: line1, line2, city, state, postcode, country, one_line."""
    cfg = REGIONS[region]
    a = dict(country=cfg["country"], state="", postcode="", city="", line1="", line2="")
    if region == "SG":
        a.update(line1=f"Blk {r.randint(1,999)} {r.choice(['Ang Mo Kio Ave 3','Tampines St 81','Jurong West St 52','Bedok North Rd','Clementi Ave 4'])}",
                 line2=f"#{r.randint(2,30):02d}-{r.randint(1,400):03d}", city="Singapore", postcode=_d(6, r))
    elif region == "MY":
        city, state, pc = r.choice(MY_AREAS)
        a.update(line1=f"No. {r.randint(1,120)}, Jalan {r.choice(['SS 2/55','Bukit Indah 3/7','Mawar 5','Tun Razak','Setia Utama 2'])}",
                 line2=f"Taman {r.choice(['Sri Murni','Bunga Raya','Mutiara','Desa Jaya','Sentosa'])}",
                 city=city, state=state, postcode=pc.format(d3=_d(3, r)))
    elif region == "HK_EN":
        a.update(line1=f"Flat {r.choice('ABCDEFG')}, {r.randint(3,38)}/F, Block {r.randint(1,9)}, {r.choice(['Sample Garden','Harmony Court','Jade Villa','Sunrise Mansion'])}",
                 line2=f"{r.randint(1,200)} {r.choice(['King Fu','Hing Wah','Wai Yip','Nathan','Tai Yau'])} Street", city=r.choice(HK_DIST_EN))
    elif region == "HK_ZH":
        a.update(line1=f"{r.choice(HK_DIST_ZH)}{r.choice(['偉業街','興華路','太子道','榮業街','大有街'])}{r.randint(1,200)}號",
                 line2=f"{r.choice(['樣本花園','和諧閣','翠玉苑','旭日大廈'])}{r.randint(1,9)}座{r.randint(3,38)}樓{r.choice('ABCDEFG')}室", city="")
    elif region == "TW":
        c, d = r.choice(TW_DIST)
        a.update(line1=f"{c}{d}{r.choice(TW_ROADS)}{r.choice(['一','二','三'])}段{r.randint(1,300)}號",
                 line2=f"{r.randint(2,20)}樓之{r.randint(1,5)}", city=f"{c}{d}", postcode=_d(3, r))
    parts = [a["line1"], a["line2"], a["city"], a["state"], a["postcode"], a["country"]]
    a["one_line"] = (" ".join if region in ("HK_ZH", "TW") else ", ".join)([p for p in parts if p])
    return a

# Fictional brands. (name_en, name_local, color, shape)
BRANDS = {
    "electric": {"SG": ("Lumenary Energy", "#e07b00", "bolt"), "MY": ("Tenaga Sample Berhad", "#0b6e4f", "bolt"),
                 "HK_EN": ("Harbour Light Power", "#c0392b", "bolt"), "HK_ZH": ("港光電力", "#c0392b", "bolt"), "TW": ("台灣示例電力", "#1f5fa8", "bolt")},
    "water_gas": {"SG": ("Aqualis Utilities", "#0a84c6", "drop"), "MY": ("Air Contoh Sdn Bhd", "#0a84c6", "drop"),
                  "HK_EN": ("Kowloon Gas & Water (Sample)", "#2a9d8f", "drop"), "HK_ZH": ("九龍燃氣水務（樣本）", "#2a9d8f", "drop"), "TW": ("示例自來水瓦斯公司", "#2a9d8f", "drop")},
    "telecom": {"SG": ("Nimbus Mobile", "#7b2cbf", "wave"), "MY": ("Celcom Contoh (Sample)", "#e63946", "wave"),
                "HK_EN": ("PacificLink Telecom", "#ff6b00", "wave"), "HK_ZH": ("太平通訊", "#ff6b00", "wave"), "TW": ("遠景電信（示例）", "#00a6a6", "wave")},
    "tv": {"SG": ("StarView Cable TV", "#d62828", "play"), "MY": ("Astra Contoh TV", "#003049", "play"),
           "HK_EN": ("Metro Vision TV", "#6a4c93", "play"), "HK_ZH": ("都會視界電視", "#6a4c93", "play"), "TW": ("天空有線電視（示例）", "#6a4c93", "play")},
    "mgmt": {"SG": ("Harbourview Estate Management", "#264653", "house"), "MY": ("Pengurusan Contoh Sdn Bhd", "#264653", "house"),
             "HK_EN": ("Greenfield Property Management Ltd", "#2d6a4f", "house"), "HK_ZH": ("綠野物業管理有限公司", "#2d6a4f", "house"), "TW": ("安居社區管理委員會", "#2d6a4f", "house")},
    "bank": {"SG": ("Meridian Sample Bank", "#9d0208", "shield"), "MY": ("Bank Contoh Berhad", "#0077b6", "shield"),
             "HK_EN": ("Victoria Example Bank (HK)", "#003566", "shield"), "HK_ZH": ("域多利示例銀行（香港）", "#003566", "shield"), "TW": ("臺灣示例商業銀行", "#8d0801", "shield")},
    "gov": {"SG": ("Department of Sample Affairs", "#1d3557", "crest"), "MY": ("Jabatan Contoh Negara", "#1d3557", "crest"),
            "HK_EN": ("Sample Affairs Department", "#14213d", "crest"), "HK_ZH": ("樣本事務署", "#14213d", "crest"), "TW": ("示例行政事務局", "#14213d", "crest")},
    "tax": {"SG": ("Sample Revenue Authority", "#023e8a", "crest"), "MY": ("Lembaga Hasil Contoh", "#023e8a", "crest"),
            "HK_EN": ("Sample Inland Revenue Department", "#0b3954", "crest"), "HK_ZH": ("樣本稅務局", "#0b3954", "crest"), "TW": ("示例國稅局", "#0b3954", "crest")},
    "insurer": {"SG": ("Orchid Assurance (Specimen)", "#6d597a", "leaf"), "MY": ("Takaful Contoh Berhad", "#386641", "leaf"),
                "HK_EN": ("Peak Life Insurance (Sample)", "#5f0f40", "leaf"), "HK_ZH": ("山頂人壽保險（樣本）", "#5f0f40", "leaf"), "TW": ("示例人壽保險公司", "#5f0f40", "leaf")},
    "employer": {"SG": ("Brightwell Technologies Pte Ltd", "#1b4965", "hex"), "MY": ("Sentosa Digital Sdn Bhd", "#1b4965", "hex"),
                 "HK_EN": ("Eastern Horizon Trading Ltd", "#1b4965", "hex"), "HK_ZH": ("東方地平線貿易有限公司", "#1b4965", "hex"), "TW": ("曙光科技股份有限公司", "#1b4965", "hex")},
}

def brand(kind, region, r):
    name, color, shape = BRANDS[kind][region]
    cfg = REGIONS[region]
    mark = name[0] if name[0].isascii() else name[0]
    return dict(name=name, color=color, shape=shape, mark=mark,
                tel=fmt(cfg["tel"], r), email=f"service@{''.join(ch for ch in name.lower() if ch.isascii() and ch.isalnum())[:14] or 'sample'}.example",
                web=f"www.{''.join(ch for ch in name.lower() if ch.isascii() and ch.isalnum())[:14] or 'sample'}.example",
                address=make_address(region, r)["one_line"])

def money(x, cfg): return f"{cfg['cur']} {x:,.2f}"

def rand_date(r, start=-120, end=-5):
    return date.today() + timedelta(days=r.randint(start, end))
