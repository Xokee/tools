#!/usr/bin/env python3
"""Batch-render synthetic proof-of-address style PDFs from Jinja/HTML templates.
All brands, people, addresses and numbers are randomly generated and fictional.
Every page carries a watermark and the PDF/HTML metadata marks the file as synthetic.

Usage:
  python generate.py --region SG --doc electric --n 5 --out out
  python generate.py --region all --doc all --n 2 --out out --html
"""
import argparse, random, sys
from datetime import timedelta
from pathlib import Path
from jinja2 import Environment, FileSystemLoader
import data_pools as dp
from i18n import labels

HERE = Path(__file__).parent
TPL_DIR = HERE / "templates"
DOCS = ["electric", "water_gas", "telecom", "tv", "mgmt", "tenancy", "gov", "tax", "bank", "bank_card", "fi_letter", "employer"]
BRAND_KIND = dict(electric="electric", water_gas="water_gas", telecom="telecom", tv="tv", mgmt="mgmt", tenancy="mgmt",
                  gov="gov", tax="tax", bank="bank", bank_card="bank", fi_letter="insurer", employer="employer")
LABEL_KEY = dict(bank_card="bank")

def digits(r, n): return "".join(str(r.randint(0, 9)) for _ in range(n))
def dfmt(d, lang): return d.strftime("%Y年%m月%d日") if lang != "en" else d.strftime("%d %b %Y")

def base_ctx(region, r):
    cfg = dp.REGIONS[region]
    today = dp.rand_date(r, -40, -3)
    start = today - timedelta(days=30)
    return dict(name=r.choice(dp.NAMES[region]), addr=dp.make_address(region, r), cur_code=cfg["cur_code"],
                account_no=f"{digits(r,3)}-{digits(r,6)}-{digits(r,2)}", bill_date=dfmt(today, cfg["lang"]),
                due_date=dfmt(today + timedelta(days=21), cfg["lang"]),
                period=f"{dfmt(start, cfg['lang'])} – {dfmt(today, cfg['lang'])}", ref=f"REF/{today.year}/{digits(r,6)}",
                your_ref=f"{digits(r,8)}"), cfg, today

def build_ctx(doc, region, r, t):
    c, cfg, today = base_ctx(region, r)
    F = lambda x: dp.money(x, cfg)
    lang = cfg["lang"]
    if doc == "electric":
        prev, paid = r.choice([0, 0, round(r.uniform(20, 90), 2)]), 0
        units = r.randint(120, 620); energy = round(units * r.uniform(0.25, 0.35), 2)
        fuel = round(units * 0.02, 2); tax = round((energy + fuel) * 0.09, 2); cur = round(energy + fuel + tax, 2)
        rd = r.randint(10000, 60000)
        c.update(prev_fmt=F(prev), paid_fmt=F(paid), current_fmt=F(cur), total_fmt=F(prev + cur), meter=digits(r, 9), prev_read=rd, curr_read=rd + units, units=units,
                 lines=[(t["energy"], F(energy)), (t["fuel"], F(fuel)), (t["gst"], F(tax))])
    elif doc == "water_gas":
        secs, total = [], 0
        for key in ("water", "gas"):
            use = r.randint(8, 40); a = round(use * r.uniform(1.0, 2.6), 2); s = round(r.uniform(3, 9), 2); total += a + s
            p = r.randint(100, 900)
            secs.append(dict(title=t[key], meter=digits(r, 8), prev=p, curr=p + use, use=use, lines=[(t["usage"], F(a)), (t["service_charge"], F(s))]))
        c.update(sections=secs, total_fmt=F(total))
    elif doc == "telecom":
        plan = round(r.uniform(18, 68), 2); extra = round(r.uniform(0, 25), 2); disc = round(r.uniform(2, 10), 2); total = plan + extra - disc
        c.update(mobile=dp.fmt({"SG": "+65 9{d3} {d4}", "MY": "+60 12-{d3} {d4}", "HK_EN": "+852 9{d3} {d4}", "HK_ZH": "+852 9{d3} {d4}", "TW": "+886 9{d2}-{d3}-{d3}"}[region].replace("{d2}", digits(r, 2)), r),
                 plan=r.choice(["5G Unlimited 100", "5G 60GB", "Lite 30GB"]) if lang == "en" else r.choice(["5G 無限數據", "5G 60GB 方案", "輕量 30GB"]),
                 data_gb=r.randint(5, 98), total_fmt=F(total),
                 lines=[(t["monthly"], F(plan)), (t["data"], F(extra)), (t["voice"] + " / " + t["sms"], F(0)), (t["discount"], "- " + F(disc))])
    elif doc == "tv":
        pk = round(r.uniform(15, 45), 2); st = round(r.uniform(3, 8), 2); hd = round(r.uniform(2, 6), 2)
        c.update(plan=r.choice(["Premium Pack", "Family Pack", "Basic Pack"]) if lang == "en" else r.choice(["尊享套餐", "家庭套餐", "基本套餐"]),
                 total_fmt=F(pk + st + hd), lines=[(t["channel_pack"], F(pk)), (t["set_top"], F(st)), (t["hd"], F(hd))])
    elif doc == "mgmt":
        mg = round(r.uniform(180, 520), 2); sk = round(mg * 0.1, 2); wt = round(r.uniform(15, 60), 2); pk = r.choice([0, 0, 150.0])
        lines = [(t["item_mgmt"], F(mg)), (t["item_sink"], F(sk)), (t["item_water"], F(wt))] + ([(t["item_park"], F(pk))] if pk else [])
        c.update(estate=r.choice(["Sample Garden Phase 2", "Harmony Court"]) if lang == "en" else r.choice(["樣本花園二期", "和諧社區大樓"]),
                 unit=c["addr"]["line2"] or c["addr"]["line1"], lines=lines, total_fmt=F(mg + sk + wt + pk),
                 bank_line=f"{dp.brand('bank', region, r)['name']} · A/C {digits(r,3)}-{digits(r,6)}-{digits(r,3)}")
    elif doc == "tenancy":
        ll = r.choice([n for n in dp.NAMES[region] if n != c["name"]])
        rent = r.choice([1800, 2400, 3200, 4500, 8000, 12000, 18000, 25000]) if region in ("SG", "MY") else r.choice([12000, 18000, 24000, 32000, 15000, 28000])
        if region in ("SG", "MY"): rent = rent / (3 if region == "MY" else 1) if region == "MY" else rent
        pa = dp.make_address(region, r)
        s = today + timedelta(days=r.randint(5, 40)); e = s + timedelta(days=365 * r.choice([1, 2]) - 1)
        c.update(landlord=dict(name=ll, id=digits(r, 8), addr=dp.make_address(region, r)["one_line"]), tenant_id=digits(r, 8),
                 prop_addr=pa["one_line"], addr=pa, agree_date=dfmt(today, lang), start=dfmt(s, lang), end=dfmt(e, lang),
                 rent_fmt=F(rent), deposit_fmt=F(rent * 2), pay_day=str(r.choice([1, 5, 15, 25])))
    elif doc == "tax":
        emp = r.randint(36, 220) * 1000; oth = r.choice([0, 1200, 3600]); inc = emp + oth; ded = int(inc * r.uniform(0.15, 0.35)); ch = inc - ded
        tax = round(ch * r.uniform(0.04, 0.12), 2); reb = round(min(tax, r.choice([0, 200, 500])), 2)
        f = lambda x: f"{x:,.2f}"
        c.update(tax_ref=f"{r.choice('STGF')}{digits(r,7)}{r.choice('ABCDEFGHJK')}", year=str(today.year - 1), employment=f(emp), other=f(oth), income=f(inc),
                 deductions=f(ded), chargeable=f(ch), tax=f(tax), rebate=f(reb), net=f(tax - reb))
    elif doc in ("bank", "bank_card"):
        op = round(r.uniform(2000, 40000), 2); bal = op; txns = []; dep = wd = 0.0
        merchants_en = ["Salary – Brightwell Tech", "Supermarket", "Utilities payment", "ATM withdrawal", "Transfer to savings", "Online shopping", "Rent payment", "Restaurant"]
        merchants_zh = ["薪金入賬", "超級市場", "公用事業繳費", "櫃員機提款", "轉賬至儲蓄", "網上購物", "租金支付", "餐廳消費"]
        names = merchants_en if lang == "en" else merchants_zh
        d0 = today - timedelta(days=30)
        for i in range(r.randint(9, 14)):
            d = d0 + timedelta(days=i * 2 + r.randint(0, 1)); is_cr = (i == 1) or r.random() < 0.2
            amt = round(r.uniform(2500, 9000) if is_cr and i == 1 else r.uniform(8, 900), 2)
            desc = names[0] if i == 1 else r.choice(names[1:])
            if doc == "bank":
                if is_cr: bal += amt; dep += amt; txns.append(dict(d=dfmt(d, lang), desc=desc, debit="", credit=f"{amt:,.2f}", bal=f"{bal:,.2f}"))
                else: bal -= amt; wd += amt; txns.append(dict(d=dfmt(d, lang), desc=desc, debit=f"{amt:,.2f}", credit="", bal=f"{bal:,.2f}"))
            else:
                txns.append(dict(d=dfmt(d, lang), desc=desc, amt=f"{amt:,.2f}")); wd += amt
        c.update(txns=txns, opening_fmt=F(op), dep_fmt=F(dep), wd_fmt=F(wd), closing_fmt=F(bal if doc == "bank" else wd),
                 branch=r.choice(["Central Branch", "East Branch"]) if lang == "en" else r.choice(["中區分行", "東區分行"]),
                 card_no=f"**** **** **** {digits(r,4)}", min_fmt=F(round(wd * 0.05 + 10, 2)), limit_fmt=F(r.choice([20000, 50000, 80000])))
    elif doc == "fi_letter":
        c.update(policy_no=f"P{digits(r,9)}", plan=r.choice(["Whole Life Protector", "Term Care 20"]) if lang == "en" else r.choice(["終身保障計劃", "定期醫療20年"]),
                 sum_fmt=F(r.choice([200000, 500000, 1000000])), prem_fmt=F(round(r.uniform(1200, 9800), 2)), inception=dfmt(today - timedelta(days=r.randint(400, 3000)), lang))
    elif doc == "employer":
        pos_en = ["Senior Analyst", "Operations Manager", "Software Engineer", "Account Executive"]; pos_zh = ["高級分析師", "營運經理", "軟體工程師", "客戶經理"]
        dep_en = ["Finance", "Operations", "Engineering", "Sales"]; dep_zh = ["財務部", "營運部", "研發部", "業務部"]
        i = r.randrange(4)
        c.update(position=(pos_en if lang == "en" else pos_zh)[i], dept=(dep_en if lang == "en" else dep_zh)[i],
                 since=dfmt(today - timedelta(days=r.randint(200, 2500)), lang), salary_fmt=F(r.randint(18, 90) * 1000 if region != "TW" else r.randint(35, 120) * 1000))
    return c

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--region", default="all", help="SG MY HK_EN HK_ZH TW or all")
    ap.add_argument("--doc", default="all", help="|".join(DOCS) + "|all")
    ap.add_argument("--n", type=int, default=1); ap.add_argument("--out", default="out"); ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--html", action="store_true", help="also save rendered HTML")
    ap.add_argument("--watermark-text", default=None, help="override watermark text (default: localized SPECIMEN text)")
    a = ap.parse_args()
    from weasyprint import HTML
    env = Environment(loader=FileSystemLoader(TPL_DIR), autoescape=True)
    css = (TPL_DIR / "_base.css").read_text()
    regions = list(dp.REGIONS) if a.region == "all" else a.region.split(",")
    docs = DOCS if a.doc == "all" else a.doc.split(",")
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    for region in regions:
        cfg = dp.REGIONS[region]
        for doc in docs:
            for i in range(a.n):
                r = random.Random(f"{a.seed}-{region}-{doc}-{i}")
                t = labels(LABEL_KEY.get(doc, doc), cfg["lang"])
                c = build_ctx(doc, region, r, t)
                b = dp.brand(BRAND_KIND[doc], region, r)
                html = env.get_template(f"{doc}.html.j2").render(t=t, c=c, b=b, css=css, html_lang=cfg["html_lang"], watermark_text=a.watermark_text)
                d = out / region; d.mkdir(exist_ok=True)
                stem = f"{doc}_{i:03d}"
                if a.html: (d / f"{stem}.html").write_text(html, encoding="utf-8")
                HTML(string=html).write_pdf(d / f"{stem}.pdf")
        print("done", region, file=sys.stderr)

if __name__ == "__main__":
    main()
