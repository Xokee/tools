# Research source notes

| Topic | Public source | What it helps establish |
|---|---|---|
| Hong Kong proof of address | https://www.td.gov.hk/en/public_services/licences_and_permits/proof_of_address/index.html | Utility, telecom, bank/insurance, government, tenancy categories; common name/address/issuer/date fields |
| Hong Kong Chinese guidance | https://www.td.gov.hk/sc/public_services/licences_and_permits/proof_of_address/index.html | Traditional Chinese terms and local wording |
| Hong Kong bank address proof | https://www.dbs.com.hk/personal/cn-eidv/resdential-address-proof.page?source=external | Utility, mobile/internet/pay TV, government correspondence, financial institution statements |
| Singapore proof of address | https://cs-prod-ses.singlife.com/content/public/sg/en/public/proof-of-address.html | NRIC, passport, driving licence, bills, government/financial institution letters, employment letters, tenancy agreements |
| Singapore tax assessment | https://www.iras.gov.sg/media/docs/default-source/uploadedfiles/where-to-find-tax-ref-and-ps-guide-2024-10-17.pdf | Address block, assessment year, income, deductions, tax computation |
| Hong Kong tax demand note | https://www.ird.gov.hk/eng/pdf/irc6401e.pdf | Tax reference, issue date, recipient address, amount payable, instalments |
| Singapore tenancy agreement | https://www.cea.gov.sg/real-estate-professionals/agreements-and-checklists/ | HDB/private residential tenancy contract structure |
| Singapore HDB tenancy agreement PDF | https://www.cea.gov.sg/docs/default-source/default-document-library/tenancy-agreement-template-for-hdb-flats.pdf | Landlord/tenant correspondence address, property, term, rent, signatures |
| Taiwan rental contract templates | https://pip.moi.gov.tw/Publicize/Info/G1020 | Taiwan Traditional Chinese rental agreement vocabulary and structure |
| Singapore bank application checklist | https://www.dbs.com.sg/personal/cards/cards-application-checklist.page | Bank statement, tax assessment and address-proof categories |
| CMB Wing Lung Bank address proof notes | https://www.cmbwinglungbank.com/wlb_corporate/files/UserFiles/nbbanner/promo/LandingPage_2019/Notes/html/en.html | Property management bills, utility bills, government and financial institution correspondence, telecom bills, stamped tenancy agreements |
