# Synthetic PoA / PoI HTML Template Pack

## Contents
- 12 document families × 3 locales (`en`, `zh-HK`, `zh-TW`) × 2 layout variants = **72 HTML templates**
- `template_index.json`: machine-readable index of every template
- `locales/labels.json`: localized labels for English, Hong Kong Traditional Chinese, Taiwan Traditional Chinese
- `data/example_record.json`: fictional sample data
- `docs/research_sources.md`: public reference sources used to guide document categories and field structure

## Important use limitation
This is a synthetic dataset template collection, not a set of authentic issuer templates. Every template includes a visible synthetic / sample warning. Issuers and marks are fictional placeholders. Identity-document layouts are intentionally generic and omit real logos, portrait photos, machine-readable zones, seals, holograms, barcodes, and security features. Do not remove the synthetic markings or present generated files as genuine identity, tax, banking, government, insurance, employment, or address documents.

## Template families
- `nric`
- `driving_licence`
- `mykad`
- `passport`
- `utility_bill`
- `management_phone_tv_bill`
- `tenancy_agreement`
- `government_letter`
- `tax_assessment`
- `bank_statement`
- `financial_institution_insurer_letter`
- `employer_letter`

## Locales
- `en`: English
- `zh-HK`: Hong Kong Traditional Chinese
- `zh-TW`: Taiwan Traditional Chinese

The locale codes describe language/formatting variants, not official jurisdiction-issued documents. Templates are starter layouts and may need your renderer to supply locale-specific date, currency, and address formatting.

## Rendering
These templates use Jinja2-style placeholders (`{{ name }}`). They are HTML files and can be rendered with Jinja2 plus Playwright/Chromium. Use autoescaping and validate all field values. The pack does not bundle a PDF renderer or third-party libraries.

Example Python outline:
```python
from pathlib import Path
import json
from jinja2 import Environment, FileSystemLoader, select_autoescape
from playwright.sync_api import sync_playwright

template_dir = Path("templates/utility_bill/en")
env = Environment(
    loader=FileSystemLoader(str(template_dir)),
    autoescape=select_autoescape(["html", "xml"])
)
data = json.loads(Path("data/example_record.json").read_text(encoding="utf-8"))
html = env.get_template("utility_bill_en_v01.html").render(**data)

with sync_playwright() as p:
    browser = p.chromium.launch()
    page = browser.new_page()
    page.set_content(html, wait_until="networkidle")
    page.pdf(path="synthetic_sample.pdf", format="A4", print_background=True)
    browser.close()
```

## Public reference research
The links below are research references for document categories, common fields, and high-level page structure. The pack does not reproduce official documents or logos.

- Hong Kong Transport Department, Proof of Address: https://www.td.gov.hk/en/public_services/licences_and_permits/proof_of_address/index.html
- Hong Kong Transport Department, Chinese version: https://www.td.gov.hk/sc/public_services/licences_and_permits/proof_of_address/index.html
- DBS Hong Kong, Proof of Residential Address: https://www.dbs.com.hk/personal/cn-eidv/resdential-address-proof.page?source=external
- Singlife Singapore, Proof of Address: https://cs-prod-ses.singlife.com/content/public/sg/en/public/proof-of-address.html
- IRAS Singapore, Notice of Assessment sample guide PDF: https://www.iras.gov.sg/media/docs/default-source/uploadedfiles/where-to-find-tax-ref-and-ps-guide-2024-10-17.pdf
- Hong Kong Inland Revenue Department, Specimen of Demand Note: https://www.ird.gov.hk/eng/pdf/irc6401e.pdf
- Hong Kong Inland Revenue Department, Demand Note for Individuals: https://www.ird.gov.hk/eng/tax/ind_dn.htm
- Singapore Council for Estate Agencies, tenancy templates: https://www.cea.gov.sg/real-estate-professionals/agreements-and-checklists/
- Singapore Council for Estate Agencies, HDB tenancy template PDF: https://www.cea.gov.sg/docs/default-source/default-document-library/tenancy-agreement-template-for-hdb-flats.pdf
- Taiwan Ministry of the Interior Real Estate Information Platform, contract templates: https://pip.moi.gov.tw/Publicize/Info/G1020
- DBS Singapore, card application checklist: https://www.dbs.com.sg/personal/cards/cards-application-checklist.page
- CMB Wing Lung Bank, notes on address proof: https://www.cmbwinglungbank.com/wlb_corporate/files/UserFiles/nbbanner/promo/LandingPage_2019/Notes/html/en.html

## Notes
- Public pages may change and some official sample documents are only provided as PDFs or explanatory pages.
- Not every source provides all requested language variants or an editable HTML template.
- The included HTML layouts are newly authored synthetic layouts informed by public category/field guidance, not direct HTML conversions of each official sample.
